﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace WpfApplication1.Classes
{
    class Connection
    {
        public static string ConStr;
        public static void Connect(string db, string serv, string user, string pwd)
        {
            SqlConnectionStringBuilder conBuild = new SqlConnectionStringBuilder();
            conBuild.DataSource = serv;
            conBuild.InitialCatalog = db;
            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pwd))
            {
                conBuild.IntegratedSecurity = true;
            }
            else
            {
                conBuild.UserID = user;
                conBuild.Password = pwd;
            }
            conBuild.ConnectTimeout = 7;
            ConStr = conBuild.ConnectionString;
        }
    }
}
