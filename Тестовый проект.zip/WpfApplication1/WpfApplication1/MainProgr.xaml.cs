﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApplication1.Classes;
using System.Data.SqlClient;
using System.IO;
using System.Collections;

namespace WpfApplication1
{
    /// <summary>
    /// Логика взаимодействия для MainProgr.xaml
    /// </summary>
    public partial class MainProgr : Window
    {
        private int idu;
        private int id_company_cur;
        private int iduser;
        private bool IsEditComp = false;
        private bool IsEditUser = false;
        DataClasses1DataContext con = new DataClasses1DataContext(Connection.ConStr);
        public MainProgr()
        {
            InitializeComponent();
           
            #region звгрузка main_inf
            var mi = (from m in con.Main_information
                      select m).ToList();
            main_inf.ItemsSource = mi;

            var clist = (from cl in con.Company
                         select cl).ToList();
            company_list.ItemsSource = clist;

            var comp = (from c in con.Company
                        select new { name = c.name_company, id = c.id_company }).ToList();
            cb_comp.ItemsSource = comp;
            cb_comp.DisplayMemberPath = "name";
            cb_comp.SelectedValuePath = "id";
         

            var userl = (from u in con.User select u).ToList();
            User_list.ItemsSource = userl;
            #endregion
            new_comp.Text = "Введите название";
        }



 

        private void Edit2(object sender, RoutedEventArgs e)
        {
            var selected_u = main_inf.SelectedItem as Main_information;


                var inf = (from i in con.Main_information
                           where i.id_user == selected_u.id_user
                           select i).FirstOrDefault();
                Combo_company.Text = conv(inf.Login);
                idu = selected_u.id_user;
                

                var comp = (from c in con.Company
                            select new { name = c.name_company, id = c.id_company }).ToList();
                Box_comp.ItemsSource = comp;
                Box_comp.DisplayMemberPath = "name";
                Box_comp.SelectedValuePath = "id";
                Zap(Box_comp, inf.id_company);

                var cs = (from c in con.C_Status
                          select new {stat = c.ContractStatus, ids = c.id_constatus }).ToList();
                Status.ItemsSource = cs;
                Status.DisplayMemberPath = "stat";
                Status.SelectedValuePath = "ids";
                Zap(Status, inf.id_constatus);
        

        }

        private void Save_cng(object sender, RoutedEventArgs e)
        {
            con = new DataClasses1DataContext(Connection.ConStr);
            try
            {
                User us;

                us = (from u in con.User
                          where u.id_user == idu
                          select u).FirstOrDefault();

                if (Box_comp.SelectedValue != null)
                {
                    us.id_company = (Int32)Box_comp.SelectedValue;
                }

                if (Status.SelectedValue != null)
                {
                    us.id_constatus = (Int32)Status.SelectedValue;
                }
                con.SubmitChanges();
                //Status.SelectedValue = null;
                //Box_comp.SelectedValue = null;
                //Combo_company.Text = null;
                var mi = (from m in con.Main_information
                          select m).ToList();
                main_inf.ItemsSource = mi;
            }
            catch
            {
                MessageBox.Show("Ошибка изменения данных");
                return;
            }
        }


        private void New_comp(object sender, RoutedEventArgs e)
        {
            con = new DataClasses1DataContext(Connection.ConStr);

            if (string.IsNullOrEmpty(new_comp.Text))
               {
                        MessageBox.Show("Введите название компании!", "Ошибка добавления", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
               }

            Company comp;
            if (IsEditComp == false)
            {
            var cn = (from c in con.Company 
                          where c.name_company == new_comp.Text
                           select c).ToList();
            if (cn.Count != 0)
            {
            MessageBox.Show("Компания с таким имененм уже существует");
            return;
            }
            comp = new Company();
            }
            else
            {
                comp = (from c in con.Company
                        where c.id_company == id_company_cur
                        select c).FirstOrDefault();
            }
            comp.name_company = new_comp.Text;
            if (IsEditComp == false)
            {
                con.Company.InsertOnSubmit(comp);
            }
            con.SubmitChanges();
            MessageBox.Show("Успешно!");
            new_comp.Text = null;
            var clist = (from cl in con.Company
                         select cl).ToList();
            company_list.ItemsSource = clist;

        }

        private void Sel_comp(object sender, RoutedEventArgs e)
        {
        IsEditComp = true;
        var sel_c = company_list.SelectedItem as Company;
        var sel_cm =(from c in con.Company
                         where c.id_company == sel_c.id_company
                         select c).FirstOrDefault();
        new_comp.Text=sel_cm.name_company;
        id_company_cur = sel_cm.id_company;
        }

        private void Del_comp(object sender, RoutedEventArgs e)
        {


            if (company_list.SelectedItem == null)
            {
                MessageBox.Show("необходимо выбрать компанию!");
                return;
            }
            else
            {
                var sel_c = company_list.SelectedItem as Company;
                if ((MessageBox.Show("Вы уверены, что хотите удалить  " + sel_c.name_company + "и всех её пользователей ?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes))
                { 
                    var sel_cm = (from c in con.Company
                              where c.id_company == sel_c.id_company
                              select c).FirstOrDefault();
                var user_comp = (from u in con.User
                                 where u.id_company == sel_c.id_company
                                 select u);
                if (user_comp != null)
                {
                    foreach (var i in user_comp)
                    {
                        con.User.DeleteAllOnSubmit(user_comp);
                        con.SubmitChanges();
                    }

                }
                con.Company.DeleteOnSubmit(sel_cm);
                con.SubmitChanges();
                MessageBox.Show("Успешно");
                #region звгрузка main_inf
                var mi = (from m in con.Main_information
                          select m).ToList();
                main_inf.ItemsSource = mi;

                var clist = (from cl in con.Company
                             select cl).ToList();
                company_list.ItemsSource = clist;

                var userl = (from u in con.User select u).ToList();
                User_list.ItemsSource = userl;
                #endregion
                }
            }
        }


        private void Sel_user(object sender, RoutedEventArgs e)
        {
            IsEditUser = true;
            var sel_u = User_list.SelectedItem as User;
            var sel_us = (from c in con.User
                          where c.id_user == sel_u.id_user
                          select c).FirstOrDefault();
            name_us.Text = sel_us.Name;
            log_us.Text = sel_us.Login;
            pass_us.Text = sel_us.Pssword;

            var comp = (from c in con.Company
                        select new { name = c.name_company, id = c.id_company }).ToList();
            cb_comp.ItemsSource = comp;
            cb_comp.DisplayMemberPath = "name";
            cb_comp.SelectedValuePath = "id";
            Zap(cb_comp, sel_us.id_company);

            iduser = sel_us.id_user;

        }


        private void New_user(object sender, RoutedEventArgs e)
        {
            con = new DataClasses1DataContext(Connection.ConStr);

            if (string.IsNullOrEmpty(name_us.Text) && string.IsNullOrEmpty(log_us.Text) && string.IsNullOrEmpty(pass_us.Text))
            {
                MessageBox.Show("Введите данные о пользователе!");
                return;
            }

            User uss;
            if (IsEditUser == false)
            {
                var usn = (from c in con.User
                          where c.Login == log_us.Text
                          select c).ToList();
                if (usn.Count != 0)
                {
                    MessageBox.Show("Пользователь с таким логином уже существует");
                    return;
                }
                uss = new User();
            }
            else
            {
                uss = (from c in con.User
                        where c.id_user == iduser
                        select c).FirstOrDefault();
            }
            uss.Name = name_us.Text;
            uss.Login = log_us.Text;
            uss.Pssword = pass_us.Text;
            uss.id_company = (Int32)cb_comp.SelectedValue;
            if (IsEditComp == false)
            {
                con.User.InsertOnSubmit(uss);
            }
            con.SubmitChanges();
            MessageBox.Show("Успешно!");
            name_us.Text = null;
            log_us.Text = null;
            pass_us.Text = null;
            cb_comp.SelectedValue = null;
            var userl = (from u in con.User select u).ToList();
            User_list.ItemsSource = userl;
            var mi = (from m in con.Main_information
                      select m).ToList();
            main_inf.ItemsSource = mi;
        }


        private void Del_user(object sender, RoutedEventArgs e)
        {
            if (User_list.SelectedItem == null)
            {
                MessageBox.Show("Необходимо выбрать пользователя!");
                return;
            }
            else
            {
                var sel_us = User_list.SelectedItem as User;
                if ((MessageBox.Show("Вы уверены, что хотите удалить  " + sel_us.Name + " ?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes))
                {
                    var sel_cu = (from c in con.User
                                  where c.id_user == sel_us.id_user
                                  select c).FirstOrDefault();


                    con.User.DeleteOnSubmit(sel_cu);

                    con.SubmitChanges();
                }
                MessageBox.Show("Успешно");
                var userl = (from u in con.User select u).ToList();
                User_list.ItemsSource = userl;
            }
        }
       // 

        //

        private string conv(string s)
        {
            if (s == null)
                return string.Empty;
            else
                return s;
        }
        private void Zap(ComboBox cmbx, int? id)
        {
            if (id == null)
                cmbx.SelectedIndex = -1;
            else
            {
                cmbx.SelectedValue = id;
            }
        }










    }
}
