﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using WpfApplication1.Classes;


namespace WpfApplication1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Server.Text = Settings.Default._server;
            DB.Text = Settings.Default._db;
            Login.Text = Settings.Default._login;
            Pass.Password = Settings.Default._password;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
             try
            {
            connect_to_db();
            MainProgr mp = new MainProgr();
            mp.Show();
            this.Hide();
            }
             catch
             {
                 MessageBox.Show("Соединение с сервером не установлено", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
             }
        
        }

        private void connect_to_db()
        {
           
                SqlConnection con = new SqlConnection();
                Connection.Connect(DB.Text, Server.Text, Login.Text, Pass.Password);
                con.ConnectionString = Connection.ConStr;
                con.Open();
                con.Close();
                
        }
    }
}
